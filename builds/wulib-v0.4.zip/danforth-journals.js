var danforth_journals = {
    "list": []
};