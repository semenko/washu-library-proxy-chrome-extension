var intersect_journals = {
    "list": []
};